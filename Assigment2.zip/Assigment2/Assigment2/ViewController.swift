//
//  ViewController.swift
//  Assigment2
//
//  Created by mac on 15/10/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchbar: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        searchbar.layer.cornerRadius=3
    }


}

